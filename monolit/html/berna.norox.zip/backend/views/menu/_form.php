<?php

use yii\helpers\Html;
use yii\helpers\Url;
use kartik\form\ActiveForm;
use common\models\Menu;
use common\models\Language;

$languages = Language::findAllActive();
$lang = Yii::$app->config->get('materialsLanguage');

/* @var $this yii\web\View */
/* @var $model backend\models\MenuForm */
/* @var $form kartik\form\ActiveForm */
?>

<div class="menu-form">

    <?php $form = ActiveForm::begin(['id' => 'form', 'type' => ActiveForm::TYPE_HORIZONTAL]); ?>

    <?= $form->field($model, 'key')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'status')->dropDownList([
        Menu::STATUS_ACTIVE => Yii::t('backend', 'Active'),
        Menu::STATUS_INACTIVE => Yii::t('backend', 'Inactive')
    ]) ?>

    <?php if(!$model->model->isNewRecord): ?>
        <div class="row">
            <div class="col-md-10 col-md-offset-2">

                <?= $model->render($form) ?>

                <div class="hidden">
                    <?= $form->field($model, 'itemsOrderJSON')->textarea(['id'=>"menu-items-output"]) ?>
                </div>

                <?php foreach ($items as $item): ?>

                    <div id="edit-modal-<?= $item->id ?>" data-id="<?= $item->id ?>" class="modal fade" tabindex="-1" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title"><?= $item->label ?></h4>
                                </div>
                                <div class="modal-body">

                                    <?= $form->field($item, '[' . $item->id . ']url')->textInput() ?>

                                    <!-- translations -->

                                    <ul class="nav nav-tabs" role="tablist">
                                        <?php $i = 0;
                                        foreach ($languages as $language): ?>
                                            <li role="presentation" class="<?= $language->code == $lang ? 'active' : '' ?>">
                                                <a href="#lang-<?= $item->id ?>-<?= $language->code ?>" aria-controls="lang-<?= $language->code ?>" role="tab"
                                                   data-toggle="tab">
                                                    <?= Html::tag('i', '', ['class' => $language->code, 'style' => 'margin-right: 5px;']) ?>
                                                    <?= Yii::t('common/language', $language->title) ?>
                                                </a>
                                            </li>
                                            <?php $i++; endforeach ?>
                                    </ul>

                                    <div class="tab-content">

                                        <?php $j = 0;
                                        foreach ($languages as $language): ?>

                                            <div class="tab-pane <?= $language->code == $lang ? 'active' : '' ?>" role="tabpanel"
                                                 id="lang-<?= $item->id ?>-<?= $language->code ?>">

                                                <?= $form->field($item->translate($language->code), '[' . $item->id . '][' . $language->code . ']label')->textInput() ?>
                                            </div>

                                            <?php $j++; endforeach ?>

                                    </div>

                                    <!-- /translations -->
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Ok</button>
                                    <!--                                <button type="button" class="btn btn-primary">Save changes</button>-->
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->

                <?php endforeach ?>

            </div>
        </div>

        <div class="row">
            <div class="col-md-10 col-md-offset-2">
                <?= Html::a('<i class="ion-plus-round"></i> ' . Yii::t('backend/menu', 'Create Item'), ['create-item', 'menu_id' => $model->model->id], ['class' => 'btn btn-sm btn-success']) ?>
            </div>
        </div>

    <?php endif ?>

    <hr>

    <?php $this->registerJs("
        $(function(){

            var updateOutput = function(e)
            {
                var list   = e.length ? e : $(e.target),
                    output = list.data('output');
                if (window.JSON) {
                    output.val(window.JSON.stringify(list.nestable('serialize')));//, null, 2));
                } else {
                    output.val('JSON browser support required for this demo.');
                }
            };


           $('#menu-items').nestable({

           })
           .on('change', updateOutput);

           updateOutput($('#menu-items').data('output', $('#menu-items-output')));


            var defaultLanguage = '" . Yii::$app->config->get('materialsLanguage') . "';
            $('[data-dismiss=modal]').on('click', function(e) {
                var modal = $(this).closest('.modal');
                var id = modal.data('id');

                li = $('#menu-items').find('.dd3-content[data-id=' + id + ']');
                li.find('.label2').html(modal.find('#menuitemtranslation-' + id + '-' + defaultLanguage + '-label').val());
                li.find('.url').html(modal.find('#menuitem-' + id + '-url').val());
            });

        });
    ") ?>

    <div class="clearfix"></div>

    <div class="well">
        <div class="pull-right">
            <?= Html::submitButton($model->model->isNewRecord ? Yii::t('backend', 'Create') : Yii::t('backend', 'Save'), ['class' => $model->model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
        </div>
        <div class="clearfix"></div>
    </div>

    <?php ActiveForm::end(); ?>

</div>
