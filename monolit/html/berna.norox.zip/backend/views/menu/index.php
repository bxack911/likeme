<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\MenuSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('backend/menu', 'Menus');
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="pull-right">
    <?= Html::a('<i class="ion-plus-round"></i> ' . Yii::t('backend/menu', 'Create Menu'), ['create'], ['class' => 'btn btn-sm btn-success']) ?>
</div>
<?= GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'tableOptions' => ['class' => 'data-table table-striped'],
    'layout' => "{items}\n{pager}\n{summary}",
    'columns' => [
        ['class' => 'yii\grid\SerialColumn'],

//            'id',
        'key',
        'name',
        //'status',
        //'created_at',
        // 'updated_at',
        // 'created_by',
        // 'updated_by',

        ['class' => 'backend\grid\ActionColumn'],
    ],
]); ?>
