<?php

namespace backend\models;

use Yii;
use yii\helpers\Html;
use yii\base\Model;
use common\models\Menu;
use common\models\MenuItem;

/**
 * @property Menu $model
 */
class MenuForm extends Model
{
    public $key;
    public $name;
    public $status;

    public $itemsOrderJSON;

    private $_model;

    public function setModel(Menu $model)
    {
        $this->_model = $model;
        $this->attributes = [
            'name' => $model->name,
            'key' => $model->key,
            'status' => $model->status,
        ];

    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'key' => Yii::t('common/menu', 'Key'),
            'name' => Yii::t('common/menu', 'Name'),
            'status' => Yii::t('common/menu', 'Status'),
            'created_at' => Yii::t('common/menu', 'Created At'),
            'updated_at' => Yii::t('common/menu', 'Updated At'),
            'created_by' => Yii::t('common/menu', 'Created By'),
            'updated_by' => Yii::t('common/menu', 'Updated By'),
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['key'], 'required'],
            [['key'],  'unique', 'targetClass' => '\common\models\Menu', 'message' => Yii::t('backend/menu', 'This key has already been taken.'), 'on' => 'create'],
            [['status'], 'integer'],
            [['key', 'name'], 'string', 'max' => 255],
            [['itemsOrderJSON'], 'safe']
        ];
    }

    public function getModel()
    {
        if (!$this->_model) {
            $this->_model = new Menu();
        }
        return $this->_model;
    }

    public function saveModel()
    {
        if($this->validate()) {
            $this->model->key = $this->key;
            $this->model->name = $this->name;
            $this->model->status = $this->status;

            $itemsOrder = json_decode($this->itemsOrderJSON);

            if(!is_null($itemsOrder)) {

                $this->saveItemsOrder($itemsOrder);
            }

            $this->model->save();

            return $this->model;
        }

        return null;
    }

    protected function saveItemsOrder($items, $parent_id = 0)
    {
        $order = 1;
        foreach ($items as $item) {
            $model = MenuItem::findOne($item->id);
            $model->parent_id = $parent_id;
            $model->order = $order;
            $model->save(false);
            if(isset($item->children) && !empty($item->children)) {
                $this->saveItemsOrder($item->children, $item->id);
            }
            $order++;
        }
    }

    protected function findItem()
    {

    }

    public function render()
    {
        $rootItems = MenuItem::find()->where(['menu_id' => $this->model->id, 'parent_id' => 0])->all();

        $menu = $this->renderList($rootItems);

        echo Html::tag('div', $menu, ['class' => 'dd', 'id' => 'menu-items']);
    }

    protected function renderList($items)
    {
        $list = [];
        foreach ($items as $item) {

            $subItems = MenuItem::find()->where(['menu_id' => $this->model->id, 'parent_id' => $item->id])
                ->orderBy('order asc')->all();
            if($subItems) {
                $ul = $this->renderList($subItems);
            } else {
                $ul = null;
            }

            $li = Html::tag('li',
                Html::tag('div', '', ['class' => 'dd-handle dd3-handle']) .
                Html::tag('div',
                    '(/<span class="url">' . $item->url . '</span>) <span class="label2">' . $item->label . '</span>' .
                    '<div class="actions"><div class="btn-group btn-group-xs">' .
                    Html::a('<span class="glyphicon glyphicon-pencil"></span>', ['#'], [
                        'title' => Yii::t('yii', 'Update'),
                        'aria-label' => Yii::t('yii', 'Update'),
                        'class' => 'btn btn-default',
                        'data-pjax' => '0',
                        'data-toggle' => 'tooltip',
                        'onclick' => "$('#edit-modal-$item->id').modal('show'); return false"
                    ]) .
                    Html::a('<span class="glyphicon glyphicon-remove"></span>', ['delete-item', 'item_id' => $item->id], [
                        'title' => Yii::t('yii', 'Delete'),
                        'aria-label' => Yii::t('yii', 'Delete'),
                        'class' => 'btn btn-danger',
                        'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                        'data-method' => 'post',
                        'data-pjax' => '0',
                        'data-toggle' => 'tooltip',
                    ]) .
                    '</div></div>'
                    ,
                    ['class' => 'dd3-content', 'data-id' => $item->id]) .
                (isset($ul) ? $ul : ''),
                ['class' => 'dd-item dd3-item', 'data-id' => $item->id]);

            $list[] = $li;
        }

        return Html::tag('ol', implode("\n", $list), ['class' => 'dd-list']);
    }
}