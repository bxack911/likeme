<?php

namespace backend\components;

use yii\web\Application;
use common\components\Configurable;

class BackendApplication extends Application
{

}