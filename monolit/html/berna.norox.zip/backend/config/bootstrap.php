<?php
Yii::setAlias('@vendor', dirname(dirname(__DIR__)) . '/vendor');